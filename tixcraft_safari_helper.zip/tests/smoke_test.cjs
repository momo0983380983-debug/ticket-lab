// Tiny dependency-free smoke test for the single-page app's main JS flows.
// Does not simulate all real Safari browser behaviors.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const {webcrypto} = require('node:crypto');

const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];

class FakeNode {
  constructor(tag = 'div') {
    this.tag = tag;
    this.children = [];
    this.listeners = {};
    this.attributes = {};
    this.value = '';
    this.textContent = '';
    this.hidden = false;
    this.className = '';
    const classes = new Set();
    this.classList = {
      toggle(name, condition) {if (condition === undefined ? !classes.has(name) : condition) classes.add(name); else classes.delete(name);},
      contains(name) {return classes.has(name);}
    };
  }
  addEventListener(name, fn) {this.listeners[name] = fn;}
  fire(name, event = {}) {return this.listeners[name]({preventDefault() {}, target: this, ...event});}
  append(...children) {this.children.push(...children);}
  replaceChildren(...children) {this.children = [...children];}
  setAttribute(name, value) {this.attributes[name] = value;}
  getContext() {
    return {
      fillRect() {}, translate() {}, rotate() {}, save() {}, restore() {},
      beginPath() {}, moveTo() {}, lineTo() {}, stroke() {},
      fillText(text) {capturedChars.push(text);}
    };
  }
  scrollIntoView() {}
}
const ids = [
  'tab-practice','tab-manual','panel-practice','panel-manual','practice-areas',
  'manual-area','manual-summary','practice-success','captcha-stage','captcha',
  'captcha-input','captcha-feedback','captcha-form','practice-summary',
  'start-practice','refresh-captcha','retry','event-url',
  'open-official','url-feedback','copy-plan','manual-feedback'
];
const nodes = new Map(ids.map(id => [id, new FakeNode(id)]));
nodes.get('captcha-stage').hidden = true;
nodes.get('practice-success').hidden = true;
nodes.get('event-url').value = 'https://tixcraft.com/ticket/area/26_btskhs/22764';
nodes.get('captcha').width = 420;
nodes.get('captcha').height = 100;
let capturedChars = [];
let opened = [];
let copied = '';
const storage = new Map();
const fakeWindow = {
  crypto: webcrypto,
  isSecureContext: true,
  open(...args) {opened.push(args);},
  scrollTo() {}
};
const context = {
  document: {
    getElementById(id) {assert(nodes.has(id), 'Unknown ID: '+id); return nodes.get(id);},
    createElement(tag) {return new FakeNode(tag);}
  },
  window: fakeWindow, crypto:webcrypto, URL, performance,
  Intl, Math, Uint32Array,
  localStorage:{setItem:(key,value)=>storage.set(key,value),getItem:key=>storage.get(key)||null},
  navigator:{clipboard:{async writeText(value) {copied = value;}}}
};
vm.runInNewContext(script, context, {filename:'index.html <script>'});
assert.equal(nodes.get('practice-areas').children.length, 11);
assert.equal(nodes.get('manual-area').children.length, 11);
nodes.get('practice-areas').children[1].fire('click');
assert.equal(nodes.get('manual-summary').textContent, '1樓C05區｜NT$ 7,980');
assert.equal(storage.get('ticketlab.area'), '1樓C05區');
nodes.get('start-practice').fire('click');
assert.equal(nodes.get('captcha-stage').hidden, false);
assert.equal(capturedChars.slice(-5).join('').length, 5);
nodes.get('captcha-input').value = '!!!!!';
nodes.get('captcha-form').fire('submit');
assert.match(nodes.get('captcha-feedback').textContent, /不正確/);
nodes.get('captcha-input').value = capturedChars.slice(-5).join('');
nodes.get('captcha-form').fire('submit');
assert.equal(nodes.get('practice-success').hidden, false);
nodes.get('tab-manual').fire('click');
assert.equal(nodes.get('tab-manual').attributes['aria-selected'], 'true');
nodes.get('event-url').value = 'https://example.com/';
nodes.get('open-official').fire('click');
assert.equal(opened.length, 0);
assert.match(nodes.get('url-feedback').textContent, /合法/);
nodes.get('event-url').value = 'https://tixcraft.com/';
nodes.get('open-official').fire('click');
assert.equal(opened.length, 1);
assert.equal(opened[0][0], 'https://tixcraft.com/');
(async () => {
  await nodes.get('copy-plan').fire('click');
  assert.match(copied, /1樓C05區.*1 張/);
  console.log('PASS: 11 areas, preference sync, fixed 1 ticket, mock captcha pass/fail, tabs, URL validation, official open, copy');
})().catch(err=>{console.error(err); process.exit(1)});
