# Ticket Lab — iPhone Safari 購票流程練習與人工輔助

這是一個可直接部署到 GitHub Pages 的**純 HTML / CSS / JavaScript** 單頁網站。檔案只有 `index.html`，不需要 Python、後端、套件、API Key、登入資料或自動化瀏覽器。

## 功能

- 模擬票區選擇：使用提供的 BTS 高雄場截圖票區與價格作為練習樣本，**不代表即時庫存或售票資訊**。
- 張數固定為 1 張。
- 使用 Canvas 在使用者裝置上**產生自製的模擬驗證碼**，由使用者手動輸入並驗證。並非辨識真實拓元驗證碼。
- 練習完成後顯示本機模擬摘要與秒數，絕不送出真實訂單。
- 人工購票輔助：儲存票區偏好、複製資訊、網址格式檢查、透過一般連結打開拓元官方網站。
- 所有資料只保存在本機瀏覽器的 localStorage（若瀏覽器允許）。

## 安全與網站規範

- **不包含**真實購票自動化、定時刷新、庫存偵測、網頁爬蟲、實際驗證碼辨識、排隊繞過、腳本注入、提交訂單或付款。
- 自動化程式購票可能違反拓元規範並導致停權。參考：https://tixcraft.com/news/detail/1143
- 真正購票必須使用者自己在官方網站完成。
- 開啟官方網站時會另開頁籤；拓元建議購票時避免多視窗或多裝置同時購票，本工具本身並非購票分頁，正式購票後請留在官方分頁操作。
- 可在進入官方購票前先關閉本練習網站頁籤，以減少混淆。

## 使用 iPhone Safari 最容易的方法 — GitHub Pages

1. 登入 GitHub，建立新 Repository，建議名稱 `ticket-lab`。
2. 把 `index.html`（和選用的 `README.md`）放到儲存庫根目錄。
3. GitHub Repository → **Settings → Pages → Build and deployment → Deploy from a branch**。
4. 選擇 `main` 與 `/(root)`，儲存。
5. 發佈完成後，打開 `https://你的GitHub帳號.github.io/ticket-lab/`。
6. 在 iPhone 的 Safari 開啟網站 → 分享 → **加入主畫面**，就能像一個 App 一樣快速開啟。

> 注意：GitHub Pages 頁面通常會公開。這個專案沒有帳密或個人資料，但不要把任何帳密、cookie、金流資訊放進程式碼或儲存庫。

## 與 Codex 協作

Codex Cloud 需要事先在 Web 或桌面端建立、發佈一個有這個 GitHub repository 的環境；建立後才能從支援的行動裝置繼續工作。你也可以先手動在 GitHub 建立 repo 並上傳本專案，再用 Codex 做後續修改。

可直接貼給 Codex：

> 請檢查這個 GitHub repository 的 `index.html`，維持純前端且支援 iPhone Safari。請改善介面可及性，為模擬票區、固定 1 張、自製 Canvas 驗證碼人工練習、複製偏好、官方網址限定驗證及外開連結撰寫測試。禁止在真實 tixCraft 網站注入腳本、監控/輪詢票況、自動點擊購票、代填實際驗證碼、繞過排隊、送出訂單或付款。完成後提供測試結果與 GitHub Pages 部署說明。

## 自動測試（在有 Node.js 的開發環境）

```bash
node tests/smoke_test.cjs
```

此測試使用極簡 DOM 模擬檢查 JavaScript 邏輯，不代表實體 iPhone Safari 已完成相容性測試。

## 手動測試清單

1. 點「模擬練習」，選不同票區；畫面選取狀態與「正式購票輔助」偏好同步。
2. 張數始終顯示 1 張。
3. 點「開始練習驗證碼」，輸入錯誤應顯示錯誤提示。
4. 點 ↻，驗證碼應更新；正確輸入時顯示成功與練習摘要。
5. 「複製票區與張數」應複製文字，或在不支援時顯示手動資訊。
6. 將 URL 改成 `https://example.com/`，必須拒絕開啟。
7. 使用 `https://tixcraft.com/`，應在新分頁開啟官方網站（可能依 Safari 設定）。
8. iPhone Safari 窄螢幕應無水平捲動，按鈕可觸控。

## 原始資料與參考

- 提供的 Discord 截圖：BTS 高雄場，2026/11/22 19:00；樣本票區價格。
- 拓元官方購票流程：https://help.tixcraft.com/hc/zh-tw/articles/4404363906961
- 拓元自動化使用公告：https://tixcraft.com/news/detail/1143
- GitHub Pages：https://docs.github.com/en/pages/quickstart
- Apple Safari 加入主畫面：https://support.apple.com/guide/iphone/bookmark-a-website-iph42ab2f3a7/ios
- OpenAI Codex Cloud：https://help.openai.com/en/articles/20001545-using-codex-cloud
